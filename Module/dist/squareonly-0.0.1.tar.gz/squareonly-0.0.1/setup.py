from setuptools import setup
setup(name='squareonly',
version='0.0.1',
description="This is a simple module which can help you to find the Area of 2D shapes",
long_description="The SquareOnly module is having simple functions you just need to call them and pass the required parameters to the function, this module can find the area of 2D shapes like circle, ractangle and many more.",
author='Sudhanshu Yadav',
author_email='sudhanshuy17@email.com',
license='PYPI',
packages=['squareonly'],
zip_safe=False)